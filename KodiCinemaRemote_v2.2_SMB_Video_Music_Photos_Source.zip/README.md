# Kodi Cinema SMB Remote v2.2 — Fold6 ↔ Google TV Kodi

本版本从原始 `KodiCinemaRemote_v2.1_Fold6_Thumbs_List_Playlist_Source.zip` 源码升级。**保留相同 applicationId**：`com.example.kodismbremote`，可覆盖旧版本升级。手机只发送 Kodi JSON-RPC 控制请求；Google TV 上的 Kodi 直接读取 SMB 文件并解码。**无需另外安装电视端 APK**，也不需要把视频/音乐/图片流经手机。

## 新版首页

旧的「电影」「电视剧」「最近添加」分类已移除。仅显示三个入口：

1. **SMB 视频**：保留视频网格缩微图、列表视图、Kodi `/image/` 图片、Kodi `/vfs/` 视频抽帧回退、手机缩略图缓存、播放弹窗、进度条、音轨/字幕、播放暂停、快进、上下一个视频与 Kodi 音量。
2. **SMB 音乐**：Kodi `Files.GetDirectory(media=music)` 浏览文件夹；显示 Kodi 音乐封面，兼容 `folder.jpg` / `cover.jpg` 等本地封面。点击歌曲时建立 playlist 0 并从所选歌曲开始，支持上一首、下一首、暂停、进度、停止、随机、循环及 Kodi 音量；长按音乐文件夹可以播放该目录全部歌曲。
3. **SMB 图片**：Kodi `Files.GetDirectory(media=pictures)` 直接读取文件夹；异步按需加载缩略图、缓存到手机。点击图片让 Kodi 打开单张；按“开始文件夹幻灯片”用 `Player.Open({item:{path,random:false,recursive:false}})` 播放；支持上一张、下一张、播放/暂停、停止、旋转、缩放。

三种模式都能切换网格/列表、搜索当前目录、通过路径标签返回上级；可点“＋ SMB 路径”直接添加 Kodi 可访问的 SMB 目录。应用从 Kodi 获取指定媒体类型的共享源，并在音乐/图片模式中补充 Kodi 已有的视频/文件共享源：不用重新扫描整个 Kodi 影音库。

**特别说明**：图片“单张快速打开”、幻灯片、上下张以及照片缩略图是否全部成功，取决于你的 Kodi 版本、可访问的 SMB 文件格式、共享访问权限。照片第一次缩微图缓存尚未完成时可能先显示占位图；下一次加载通常更快。Kodi 的 HTTP `/vfs/` 对能访问的来源有安全限制。

## S61B + W510 音乐声音建议

音乐控制区新增“♫ S61B + W510 音乐音效建议”，包含 Standard 原音、Music 氛围、Adaptive Sound 人声及夜间低频建议。

- 声音模式由 **S61B 遥控器或 SmartThings** 调节；S61B 官方模式包含 Adaptive Sound、DTS Virtual:X、Music、Game、Standard。
- Woofer 建议从 `0` 调起，按听感逐步微调；这些是听感起点，不是测量校准数据。
- **Kodi JSON-RPC 不提供直接调节三星 soundbar 的硬件 EQ、Woofer 或音效模式的通用接口**。本 App 的音效功能是**手动配置指南**，不会声称自动应用到 S61B。Kodi 音量调整在音频透传或固定输出模式下可能无效。

## 配置与测试

1. Google TV 上打开 Kodi，启用 **设置 → 服务 → 控制 → 允许通过 HTTP 远程控制**；确认电视 IP、端口、用户名/密码。示例端口 `8080`。电视和 Fold6 使用同一个局域网。
2. 在 Kodi 中添加/确认 SMB 共享源，且该账号可以读音乐和图片文件夹。若 Kodi 仅添加过视频共享源，也可在新版音乐/图片页浏览同一路径。若列表没有入口，点击“＋ SMB 路径”输入如 `smb://192.168.0.10/share/music/`。优先在电视 Kodi 中预先保存 SMB 登录信息。**勿把 SMB 硬盘 IP 误填为 Kodi 的电视 IP**。
3. 手机连接 Kodi 后，先在视频页验证原有缩微图与播放/上下一个，再在音乐页试播包含 2–3 首 MP3/FLAC 的文件夹，最后在图片页试播含 JPG/PNG 的文件夹，验证幻灯片与上一张/下一张。
4. 特别是播放状态、歌词和声音模式：本版本未实现歌词、S61B 自动音效切换、文件删除或图片编辑。仅提供支持的远程控制。

## GitHub Actions 编译 APK（无需本地 Android Studio）

完整项目内包含 `.github/workflows/build-apk.yml`，要求 Gradle 8.9 / AGP 8.7.3 / JDK 17 / Android SDK 35。编译出的包名为 `com.example.kodismbremote`，版本 `2.2.0`。

**推荐方式**：把 ZIP 解压后的所有文件和隐藏的 `.github` 目录上传到 GitHub 仓库根目录（覆盖旧版），然后进入 Actions → `Build Kodi Cinema Remote APK` → Run workflow，下载 `KodiCinemaRemote-v2.2-debug` 工件，解压得到 `KodiCinemaRemote-v2.2-debug.apk`。

**只上传 ZIP 的方式**：若仓库已经有可运行的 `.github/workflows/build-apk.yml`，先删除仓库中旧版 Kodi Cinema 项目 ZIP，再上传本 v2.2 ZIP。原有 workflow 若仍使用 v2.1 文件名，编译的应用可能已是 v2.2 但工件会显示旧名称；建议把 ZIP 内新版 workflow 文件也覆盖到仓库相同位置。没有现成 workflow 的仓库，**仅上传 ZIP 不会自动创建 Actions 工作流**。

**交付状态**：提供完整 Android 源码和 CI 配置。本地环境无 Android SDK 与 Gradle，因此没有在本机完成真正的 Android 编译，也没有连到你的 Kodi/SMB 真机联调；请通过 GitHub Actions 检查编译和实测。旧版 v2.1 APK **不是**本新版 APK。

## 数据和安全

HTTP Basic Auth 仅适用于可信家庭局域网，切勿将 8080 暴露到公网。手机端不持久保存 Kodi 密码。手动加入的 SMB 目录只保存路径字符串，不会复制文件。

## API 文档

- https://kodi.wiki/view/JSON-RPC_API/v12
- https://kodi.wiki/view/Web_server
- https://kodi.wiki/view/Artwork/Accessing_with_skins_and_JSON-RPC
- https://kodi.wiki/view/Pictures
- https://www.samsung.com/latin/audio-devices/soundbar/s61b-white-hw-s61b-zp/
