package com.example.kodismbremote;

import android.app.Activity;
import android.app.AlertDialog;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.util.Base64;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** No third-party libraries. Kodi credentials stay in RAM, not preferences. */
public class MainActivity extends Activity {
    private static final int BG = Color.rgb(12, 16, 25);
    private static final int SURFACE = Color.rgb(26, 33, 47);
    private static final int TEXT = Color.rgb(237, 241, 247);
    private static final int MUTED = Color.rgb(155, 171, 195);
    private static final int ACCENT = Color.rgb(70, 170, 247);
    private static final int BORDER = Color.rgb(48, 60, 77);

    private final ExecutorService network = Executors.newSingleThreadExecutor();
    private final Handler ui = new Handler(Looper.getMainLooper());
    private EditText hostField, portField, userField, passField, searchField;
    private TextView statusText, pathText, nowText, timeText, actionTitle;
    private ProgressBar loading;
    private SeekBar seek;
    private ListView filesList;
    private Button backButton, playButton;
    private final ArrayList<BrowserItem> currentItems = new ArrayList<>();
    private final ArrayList<BrowserItem> filteredItems = new ArrayList<>();
    private final ArrayList<String> history = new ArrayList<>();
    private FileAdapter adapter;
    private String host = "", port = "8080", username = "", password = "";
    private String currentPath = "";
    private boolean connected = false, seeking = false, busy = false;
    private int playerId = -1;
    private long lastStatusAt = 0L;

    private static class BrowserItem {
        String name, path;
        boolean directory;
        BrowserItem(String name, String path, boolean directory) {
            this.name = name;
            this.path = path;
            this.directory = directory;
        }
    }

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        buildUi();
        hostField.setText(getPreferences(MODE_PRIVATE).getString("host", "192.168.0.79"));
        portField.setText(getPreferences(MODE_PRIVATE).getString("port", "8080"));
        userField.setText(getPreferences(MODE_PRIVATE).getString("user", "kodi"));
        ui.postDelayed(poller, 2300);
    }

    private int dp(int px) { return Math.round(getResources().getDisplayMetrics().density * px); }
    private LinearLayout.LayoutParams lp(int w, int h) {
        return new LinearLayout.LayoutParams(w < 0 ? w : dp(w), h < 0 ? h : dp(h));
    }
    private LinearLayout vertical() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        return l;
    }
    private LinearLayout horizontal() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.HORIZONTAL);
        l.setGravity(Gravity.CENTER_VERTICAL);
        return l;
    }
    private TextView text(String label, int sp, int color, boolean bold) {
        TextView v = new TextView(this);
        v.setText(label);
        v.setTextSize(sp);
        v.setTextColor(color);
        if (bold) v.setTypeface(null, Typeface.BOLD);
        v.setGravity(Gravity.CENTER_VERTICAL);
        return v;
    }
    private EditText input(String hint, boolean secret) {
        EditText e = new EditText(this);
        e.setSingleLine(true);
        e.setTextColor(TEXT);
        e.setHintTextColor(MUTED);
        e.setHint(hint);
        e.setTextSize(14);
        e.setPadding(dp(9), dp(5), dp(9), dp(5));
        if (secret) e.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        return e;
    }
    private Button button(String name, View.OnClickListener handler) {
        Button b = new Button(this);
        b.setText(name);
        b.setTextSize(12);
        b.setTextColor(TEXT);
        b.setAllCaps(false);
        b.setOnClickListener(handler);
        return b;
    }
    private void addSpacer(LinearLayout parent, int pixels) {
        View v = new View(this);
        parent.addView(v, lp(1, pixels));
    }
    private void buildUi() {
        LinearLayout root = vertical();
        root.setBackgroundColor(BG);
        root.setPadding(dp(12), dp(8), dp(12), dp(4));
        setContentView(root);

        TextView title = text("KODI  ·  SMB REMOTE", 19, TEXT, true);
        root.addView(title, lp(-1, 32));
        statusText = text("未连接 · 先打开 Google TV 上的 Kodi", 12, MUTED, false);
        root.addView(statusText, lp(-1, 27));

        LinearLayout connect = vertical();
        connect.setPadding(dp(8), dp(4), dp(8), dp(4));
        connect.setBackgroundColor(SURFACE);
        root.addView(connect, lp(-1, -2));
        LinearLayout address = horizontal();
        hostField = input("Google TV IP", false);
        portField = input("端口", false);
        portField.setInputType(InputType.TYPE_CLASS_NUMBER);
        address.addView(hostField, new LinearLayout.LayoutParams(0, dp(41), 3f));
        address.addView(portField, new LinearLayout.LayoutParams(0, dp(41), 1f));
        connect.addView(address);
        LinearLayout credentials = horizontal();
        userField = input("Kodi 用户名", false);
        passField = input("Kodi 密码（不保存）", true);
        credentials.addView(userField, new LinearLayout.LayoutParams(0, dp(41), 1f));
        credentials.addView(passField, new LinearLayout.LayoutParams(0, dp(41), 1.6f));
        connect.addView(credentials);
        Button connectButton = button("连接 Kodi / 读取 SMB 视频源", v -> connect());
        connectButton.setTextColor(ACCENT);
        connect.addView(connectButton, lp(-1, 43));

        LinearLayout browseHeading = horizontal();
        backButton = button("‹ 返回", v -> goBack());
        browseHeading.addView(backButton, lp(83, 40));
        pathText = text("视频文件夹", 13, MUTED, true);
        pathText.setSingleLine(true);
        pathText.setEllipsize(android.text.TextUtils.TruncateAt.MIDDLE);
        browseHeading.addView(pathText, new LinearLayout.LayoutParams(0, dp(42), 1f));
        Button rootButton = button("视频源", v -> fetchSources());
        browseHeading.addView(rootButton, lp(73, 40));
        root.addView(browseHeading, lp(-1, 43));

        searchField = input("搜索当前文件夹（按名称过滤）", false);
        root.addView(searchField, lp(-1, 40));
        searchField.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) { }
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) { filterItems(); }
            @Override public void afterTextChanged(Editable s) { }
        });

        filesList = new ListView(this);
        filesList.setDividerHeight(dp(1));
        filesList.setDivider(new android.graphics.drawable.ColorDrawable(BORDER));
        filesList.setCacheColorHint(BG);
        filesList.setBackgroundColor(SURFACE);
        adapter = new FileAdapter();
        filesList.setAdapter(adapter);
        filesList.setOnItemClickListener((parent, view, position, id) -> {
            BrowserItem item = filteredItems.get(position);
            if (item.directory) {
                history.add(currentPath);
                openDirectory(item.path);
            } else {
                openFile(item);
            }
        });
        root.addView(filesList, new LinearLayout.LayoutParams(-1, 0, 1f));

        loading = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        loading.setIndeterminate(true);
        loading.setVisibility(View.GONE);
        root.addView(loading, lp(-1, 3));

        LinearLayout controls = vertical();
        controls.setPadding(dp(8), dp(4), dp(8), dp(6));
        controls.setBackgroundColor(SURFACE);
        root.addView(controls, lp(-1, -2));
        actionTitle = text("电视正在播放", 11, ACCENT, true);
        controls.addView(actionTitle, lp(-1, 21));
        nowText = text("暂无播放内容", 14, TEXT, true);
        nowText.setSingleLine(true);
        nowText.setEllipsize(android.text.TextUtils.TruncateAt.MIDDLE);
        controls.addView(nowText, lp(-1, 25));
        seek = new SeekBar(this);
        seek.setMax(1000);
        controls.addView(seek, lp(-1, 30));
        seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar bar, int progress, boolean fromUser) {
                if (fromUser) timeText.setText(String.format(Locale.getDefault(), "跳到 %.1f%%", progress / 10.0));
            }
            @Override public void onStartTrackingTouch(SeekBar bar) { seeking = true; }
            @Override public void onStopTrackingTouch(SeekBar bar) {
                final double percent = bar.getProgress() / 10.0;
                seeking = false;
                controlPlayer("Player.Seek", json("value", json("percentage", percent)));
            }
        });
        timeText = text("00:00 / 00:00", 12, MUTED, false);
        timeText.setGravity(Gravity.CENTER);
        controls.addView(timeText, lp(-1, 23));
        LinearLayout buttons = horizontal();
        buttons.addView(button("−10 秒", v -> controlPlayer("Player.Seek", json("value", json("seconds", -10)))), new LinearLayout.LayoutParams(0, dp(43), 1f));
        playButton = button("播放/暂停", v -> controlPlayer("Player.PlayPause", json("play", "toggle")));
        playButton.setTextColor(ACCENT);
        buttons.addView(playButton, new LinearLayout.LayoutParams(0, dp(43), 1.4f));
        buttons.addView(button("+30 秒", v -> controlPlayer("Player.Seek", json("value", json("seconds", 30)))), new LinearLayout.LayoutParams(0, dp(43), 1f));
        buttons.addView(button("停止", v -> controlPlayer("Player.Stop", new JSONObject())), new LinearLayout.LayoutParams(0, dp(43), 0.8f));
        controls.addView(buttons, lp(-1, 43));
        LinearLayout advanced = horizontal();
        advanced.addView(button("音轨选择", v -> selectStream(false)), new LinearLayout.LayoutParams(0, dp(41), 1f));
        advanced.addView(button("字幕选择", v -> selectStream(true)), new LinearLayout.LayoutParams(0, dp(41), 1f));
        advanced.addView(button("刷新状态", v -> refreshPlayback()), new LinearLayout.LayoutParams(0, dp(41), 1f));
        controls.addView(advanced, lp(-1, 41));
    }

    private JSONObject json(String key, Object value) {
        JSONObject j = new JSONObject();
        try { j.put(key, value); } catch (JSONException ignored) { }
        return j;
    }

    private interface BackgroundOperation { void run() throws Exception; }
    private void runTask(BackgroundOperation operation) {
        network.execute(() -> {
            try { operation.run(); }
            catch (Exception e) { messageError(e); }
        });
    }
    private void messageError(Exception e) {
        final String msg = e.getMessage() == null ? e.getClass().getSimpleName() : e.getMessage();
        ui.post(() -> {
            loading.setVisibility(View.GONE);
            statusText.setText("错误: " + msg);
            Toast.makeText(this, msg, Toast.LENGTH_LONG).show();
        });
    }

    private JSONObject rpc(String method, JSONObject params) throws Exception {
        if (host.isEmpty()) throw new Exception("请先连接 Kodi");
        URL url = new URL("http://" + host + ":" + port + "/jsonrpc");
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setRequestMethod("POST");
        conn.setConnectTimeout(3500);
        conn.setReadTimeout(6500);
        conn.setDoOutput(true);
        conn.setRequestProperty("Content-Type", "application/json; charset=utf-8");
        conn.setRequestProperty("Accept", "application/json");
        if (!username.isEmpty() || !password.isEmpty()) {
            String auth = username + ":" + password;
            String b64 = Base64.encodeToString(auth.getBytes(StandardCharsets.UTF_8), Base64.NO_WRAP);
            conn.setRequestProperty("Authorization", "Basic " + b64);
        }
        JSONObject body = new JSONObject();
        body.put("jsonrpc", "2.0");
        body.put("method", method);
        body.put("id", 1);
        if (params != null) body.put("params", params);
        byte[] request = body.toString().getBytes(StandardCharsets.UTF_8);
        try {
            conn.setFixedLengthStreamingMode(request.length);
            try (OutputStream out = conn.getOutputStream()) { out.write(request); }
            int status = conn.getResponseCode();
            if (status == 401) throw new Exception("Kodi 密码或用户名错误 (HTTP 401)");
            if (status != 200) throw new Exception("Kodi HTTP " + status);
            ByteArrayOutputStream buffer = new ByteArrayOutputStream();
            try (InputStream in = conn.getInputStream()) {
                byte[] chunk = new byte[8192];
                int n;
                while ((n = in.read(chunk)) != -1) buffer.write(chunk, 0, n);
            }
            JSONObject reply = new JSONObject(buffer.toString("UTF-8"));
            if (reply.has("error")) {
                JSONObject err = reply.optJSONObject("error");
                throw new Exception("Kodi API: " + (err == null ? reply.optString("error") : err.optString("message")));
            }
            return reply;
        } finally { conn.disconnect(); }
    }

    private void connect() {
        String newHost = hostField.getText().toString().trim();
        String newPort = portField.getText().toString().trim();
        if (!newHost.matches("[a-zA-Z0-9.\\-]+") || newHost.isEmpty()) {
            Toast.makeText(this, "请填写局域网 IP 或主机名", Toast.LENGTH_LONG).show();
            return;
        }
        if (!newPort.matches("\\d{1,5}")) { Toast.makeText(this, "端口不正确", Toast.LENGTH_SHORT).show(); return; }
        int p = Integer.parseInt(newPort);
        if (p <= 0 || p > 65535) { Toast.makeText(this, "端口范围 1~65535", Toast.LENGTH_SHORT).show(); return; }
        host = newHost;
        port = newPort;
        username = userField.getText().toString().trim();
        password = passField.getText().toString();
        connected = false;
        getPreferences(MODE_PRIVATE).edit().putString("host", host).putString("port", port).putString("user", username).apply();
        statusText.setText("连接中...");
        loading.setVisibility(View.VISIBLE);
        runTask(() -> {
            rpc("JSONRPC.Ping", new JSONObject());
            connected = true;
            ui.post(() -> statusText.setText("✓ 已连接 " + host + ":" + port));
            loadSources();
            pollStatus();
        });
    }
    private void fetchSources() {
        if (!connected) { Toast.makeText(this, "请先连接 Kodi", Toast.LENGTH_SHORT).show(); return; }
        history.clear();
        loading.setVisibility(View.VISIBLE);
        runTask(this::loadSources);
    }
    private void loadSources() throws Exception {
        JSONObject response = rpc("Files.GetSources", json("media", "video"));
        JSONArray sources = response.optJSONObject("result") == null ? new JSONArray() : response.getJSONObject("result").optJSONArray("sources");
        ArrayList<BrowserItem> items = new ArrayList<>();
        if (sources != null) for (int i = 0; i < sources.length(); i++) {
            JSONObject s = sources.getJSONObject(i);
            items.add(new BrowserItem(s.optString("label", "视频源 " + (i + 1)), s.optString("file"), true));
        }
        ui.post(() -> {
            currentPath = "";
            history.clear();
            pathText.setText("Kodi 视频源（先在电视添加 SMB）");
            loading.setVisibility(View.GONE);
            showItems(items);
            if (items.isEmpty()) statusText.setText("已连接，但 Kodi 尚未添加视频源");
        });
    }
    private void openDirectory(String directory) {
        if (!connected) return;
        pathText.setText("读取目录中...");
        loading.setVisibility(View.VISIBLE);
        runTask(() -> {
            JSONObject parameters = json("directory", directory);
            parameters.put("media", "video");
            JSONObject response = rpc("Files.GetDirectory", parameters);
            JSONObject result = response.optJSONObject("result");
            JSONArray files = result == null ? null : result.optJSONArray("files");
            ArrayList<BrowserItem> items = new ArrayList<>();
            if (files != null) for (int i = 0; i < files.length(); i++) {
                JSONObject file = files.getJSONObject(i);
                boolean dir = "directory".equals(file.optString("filetype"));
                String path = file.optString("file");
                if (path.isEmpty()) continue;
                String name = file.optString("label");
                if (name.isEmpty()) name = path;
                items.add(new BrowserItem(name, path, dir));
            }
            items.sort(Comparator.comparing((BrowserItem x) -> !x.directory).thenComparing(x -> x.name.toLowerCase(Locale.ROOT)));
            ui.post(() -> {
                currentPath = directory;
                pathText.setText(directory);
                loading.setVisibility(View.GONE);
                searchField.setText("");
                showItems(items);
            });
        });
    }
    private void showItems(ArrayList<BrowserItem> items) {
        currentItems.clear();
        currentItems.addAll(items);
        filterItems();
    }
    private void filterItems() {
        if (adapter == null) return;
        String filter = searchField.getText().toString().trim().toLowerCase(Locale.ROOT);
        filteredItems.clear();
        for (BrowserItem item : currentItems) {
            if (filter.isEmpty() || item.name.toLowerCase(Locale.ROOT).contains(filter)) filteredItems.add(item);
        }
        adapter.notifyDataSetChanged();
    }
    private void goBack() {
        if (!connected) return;
        if (history.isEmpty()) { fetchSources(); return; }
        String previous = history.remove(history.size() - 1);
        if (previous.isEmpty()) fetchSources(); else openDirectory(previous);
    }
    private void openFile(BrowserItem item) {
        if (!connected) return;
        statusText.setText("请求 Google TV 播放：" + item.name);
        loading.setVisibility(View.VISIBLE);
        runTask(() -> {
            rpc("Player.Open", json("item", json("file", item.path)));
            ui.post(() -> {
                nowText.setText(item.name);
                statusText.setText("已发送播放指令到 Google TV");
                loading.setVisibility(View.GONE);
            });
            Thread.sleep(650);
            pollStatus();
        });
    }

    private int getPlayerId() throws Exception {
        JSONObject response = rpc("Player.GetActivePlayers", new JSONObject());
        JSONArray result = response.optJSONArray("result");
        if (result == null || result.length() == 0) return -1;
        for (int i = 0; i < result.length(); i++) {
            JSONObject p = result.getJSONObject(i);
            if ("video".equals(p.optString("type"))) return p.optInt("playerid", -1);
        }
        return result.getJSONObject(0).optInt("playerid", -1);
    }
    private void controlPlayer(String method, JSONObject extras) {
        if (!connected) { Toast.makeText(this, "请先连接 Kodi", Toast.LENGTH_SHORT).show(); return; }
        runTask(() -> {
            int id = getPlayerId();
            if (id < 0) throw new Exception("Kodi 当前没有播放内容");
            extras.put("playerid", id);
            rpc(method, extras);
            pollStatus();
        });
    }
    private void selectStream(boolean subtitles) {
        if (!connected) { Toast.makeText(this, "请先连接 Kodi", Toast.LENGTH_SHORT).show(); return; }
        runTask(() -> {
            int id = getPlayerId();
            if (id < 0) throw new Exception("当前没有播放中的影片");
            String key = subtitles ? "subtitles" : "audiostreams";
            JSONArray properties = new JSONArray().put(key);
            if (subtitles) properties.put("subtitleenabled");
            JSONObject response = rpc("Player.GetProperties", json("playerid", id).put("properties", properties));
            JSONObject result = response.optJSONObject("result");
            JSONArray choices = result == null ? null : result.optJSONArray(key);
            if (choices == null || choices.length() == 0) throw new Exception(subtitles ? "此视频没有可选字幕" : "此视频没有可选音轨");
            ArrayList<String> labels = new ArrayList<>();
            ArrayList<Integer> indices = new ArrayList<>();
            if (subtitles) { labels.add("关闭字幕"); indices.add(-1); }
            for (int i = 0; i < choices.length(); i++) {
                JSONObject c = choices.getJSONObject(i);
                String language = c.optString("language", "未知语言");
                String name = c.optString("name", "");
                String codec = c.optString("codec", "");
                labels.add((i + 1) + ". " + language + (name.isEmpty() ? "" : " · " + name) + (codec.isEmpty() ? "" : " · " + codec));
                indices.add(c.optInt("index", i));
            }
            ui.post(() -> new AlertDialog.Builder(this)
                .setTitle(subtitles ? "选择字幕" : "选择音轨")
                .setItems(labels.toArray(new String[0]), (dialog, selected) -> {
                    JSONObject arguments = new JSONObject();
                    try {
                        if (subtitles) {
                            if (indices.get(selected) < 0) arguments.put("subtitle", "off");
                            else { arguments.put("subtitle", indices.get(selected)); arguments.put("enable", true); }
                        } else arguments.put("stream", indices.get(selected));
                    } catch (JSONException ignored) { }
                    controlPlayer(subtitles ? "Player.SetSubtitle" : "Player.SetAudioStream", arguments);
                }).setNegativeButton("取消", null).show());
        });
    }
    private void refreshPlayback() {
        if (!connected) return;
        runTask(this::pollStatus);
    }
    private final Runnable poller = new Runnable() {
        @Override public void run() {
            if (connected && System.currentTimeMillis() - lastStatusAt > 2200) refreshPlayback();
            ui.postDelayed(this, 2700);
        }
    };
    private void pollStatus() {
        try {
            lastStatusAt = System.currentTimeMillis();
            final int id = getPlayerId();
            playerId = id;
            if (id < 0) {
                ui.post(() -> {
                    nowText.setText("当前没有播放内容");
                    timeText.setText("00:00 / 00:00");
                    if (!seeking) seek.setProgress(0);
                    playButton.setText("播放/暂停");
                });
                return;
            }
            JSONObject details = rpc("Player.GetProperties", json("playerid", id)
                .put("properties", new JSONArray().put("time").put("totaltime").put("percentage").put("speed")));
            JSONObject props = details.optJSONObject("result");
            JSONObject itemResponse = rpc("Player.GetItem", json("playerid", id));
            JSONObject itemResult = itemResponse.optJSONObject("result");
            JSONObject item = itemResult == null ? null : itemResult.optJSONObject("item");
            String candidateName = item == null ? "播放中" : item.optString("label", "播放中");
            if (candidateName.isEmpty()) candidateName = item == null ? "播放中" : item.optString("file", "播放中");
            final String filename = candidateName;
            double pct = props == null ? 0 : props.optDouble("percentage", 0);
            JSONObject time = props == null ? null : props.optJSONObject("time");
            JSONObject total = props == null ? null : props.optJSONObject("totaltime");
            String timer = formatTime(time) + " / " + formatTime(total);
            boolean paused = props != null && props.optInt("speed", 1) == 0;
            ui.post(() -> {
                nowText.setText(filename);
                if (!seeking) {
                    seek.setProgress((int) Math.max(0, Math.min(1000, pct * 10)));
                    timeText.setText(timer);
                }
                playButton.setText(paused ? "继续播放" : "暂停");
            });
        } catch (Exception e) {
            // Polling is passive: don't show intrusive connection error toasts every few seconds.
            ui.post(() -> statusText.setText("状态查询失败，请确认 Kodi 仍在运行"));
        }
    }
    private String formatTime(JSONObject time) {
        if (time == null) return "00:00";
        int hours = time.optInt("hours", 0);
        int minutes = time.optInt("minutes", 0);
        int seconds = time.optInt("seconds", 0);
        return hours > 0 ? String.format(Locale.ROOT, "%d:%02d:%02d", hours, minutes, seconds)
            : String.format(Locale.ROOT, "%02d:%02d", minutes, seconds);
    }
    private class FileAdapter extends BaseAdapter {
        @Override public int getCount() { return filteredItems.size(); }
        @Override public Object getItem(int position) { return filteredItems.get(position); }
        @Override public long getItemId(int position) { return position; }
        @Override public View getView(int position, View convertView, ViewGroup parent) {
            BrowserItem item = filteredItems.get(position);
            LinearLayout row = horizontal();
            row.setPadding(dp(10), dp(6), dp(8), dp(6));
            TextView icon = text(item.directory ? "▣" : "▶", 19, item.directory ? ACCENT : Color.rgb(113, 231, 182), true);
            icon.setGravity(Gravity.CENTER);
            row.addView(icon, lp(31, 45));
            LinearLayout info = vertical();
            TextView label = text(item.name, 14, TEXT, item.directory);
            label.setSingleLine(true);
            label.setEllipsize(android.text.TextUtils.TruncateAt.END);
            info.addView(label, lp(-1, 27));
            TextView second = text(item.directory ? "文件夹 · 点击浏览" : "点击后在 Google TV 播放", 11, MUTED, false);
            info.addView(second, lp(-1, 19));
            row.addView(info, new LinearLayout.LayoutParams(0, dp(50), 1f));
            return row;
        }
    }
    @Override protected void onDestroy() {
        ui.removeCallbacks(poller);
        network.shutdownNow();
        super.onDestroy();
    }
}
