# Kodi SMB Remote · Fold6 Android App

Android 手机端：通过 Kodi JSON-RPC 列出电视端添加的 SMB 视频源，进入文件夹，点选视频由 Google TV 的 Kodi 直接播放，并提供播放、暂停、跳转、停止、音轨/字幕选择和进度状态。手机不转发视频流。

## 必须事先设置的 Kodi（安装在 Google TV 上）

1. 打开 Kodi，在「视频 → 文件 → 添加视频」添加电脑或 NAS 的 SMB 文件夹，并确认 Kodi 自己能播放。
2. Kodi → 设置 → 服务 → 控制：启用「允许通过 HTTP 远程控制」，端口填 `8080`，开启认证并设置用户名和强密码。
3. 查看 Google TV 的局域网 IP（例如 `192.168.0.79`，必须以当前实际地址为准），保持 Kodi 在电视上运行。
4. 手机连接同一个可互访的局域网。在手机 App 中输入 IP、端口、用户名和密码并点击「连接 / 视频源」。
5. 从列表打开 SMB 文件夹并点电影，Kodi 会自动开始播放。

**限制：** Kodi API 无法在 Kodi 已退出/被系统停止时自行启动 Kodi。该 App 的 HTTP 通信只用于可信家庭 LAN，账号信息采用 HTTP Basic Auth 传输，未加密。请勿转发 8080 端口到互联网；推荐单独设置 Kodi 密码。App 只保存 IP、端口和用户名；密码仅存当前进程内存，不写入本地存储。如果家庭路由器/Deco 开启客户端隔离，手机与电视无法互联。播放界面的音量和音质由 Google TV、分离器、Soundbar 与 Kodi 输出决定。

## GitHub Actions 自动编译

1. 创建一个新的公开或私人 GitHub 仓库，例如 `KodiSMBRemote`。
2. **解压 ZIP，并将解压后目录里的所有文件（包含隐藏的 `.github` 文件夹）上传到仓库根目录。** GitHub Web `Upload files` 不会自动解压单个 ZIP。
3. 在 GitHub 的 `Actions` 标签选 `Build Kodi SMB Remote APK` → `Run workflow`；上传到 main/master 分支也会自动运行。
4. 编译成功后，下载 `KodiSMBRemote-v1.0.0-debug` 构件，解压得到 `app-debug.apk`，安装到 Fold6。

需要 Java 17、Gradle 8.9、Android SDK 35；GitHub Actions 自动配置。源码不依赖第三方 Android 库。APK 为调试签名，适合个人测试。

## API

- `Files.GetSources` 列出 Kodi 已配置的视频源。
- `Files.GetDirectory` 列出 SMB 目录与媒体文件。
- `Player.Open` 在 Kodi 播放文件。
- `Player.GetActivePlayers`, `Player.GetItem`, `Player.GetProperties` 同步播放信息。
- `Player.PlayPause`, `Player.Seek`, `Player.Stop`, `Player.SetAudioStream`, `Player.SetSubtitle` 远程控制。

Kodi JSON-RPC 官方文档：https://kodi.wiki/view/JSON-RPC_API

## 安全与隐私

- 不存储 Kodi 密码到 SharedPreferences；重启 App 后需重新输入。
- 强烈建议仅在受信任家庭内网使用，不要开放公网访问。
- 本 App **不访问 SMB 凭据**，只浏览 Kodi 已授权的视频源；SMB 用户名及密码仍由电视端 Kodi 管理。
