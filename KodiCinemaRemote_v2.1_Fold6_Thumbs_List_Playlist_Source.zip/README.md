# CINEMA / KODI v2.1 — Fold6 私人影院

基于用户已能正常访问 `airdisk`、控制 Google TV 播放的 v2.0 版本升级。继续沿用包名 `com.example.kodismbremote`，无需安装电视端插件，仍由 Google TV 上 Kodi 直接读取 SMB 视频。手机不接收或转发影片播放流。

## v2.1 修改内容

- **缩微图**：先尝试读取 Kodi JSON-RPC 提供的 `thumbnail` 并经 `/image/` 下载；若未提供或下载失败，针对 SMB 视频尝试通过 Kodi HTTP `/vfs/` 由 Android `MediaMetadataRetriever` 抽帧（约 15 秒处），并缓存 JPEG 到手机。是否能成功取帧取决于电视 Kodi VFS HTTP 访问权限、视频封装格式和系统媒体提取器支持，**不能保证所有视频都有缩微图**。此功能需要实际连机测试。
- **上下一个**：从 SMB 文件夹播放时，使用 Kodi `Playlist.Clear` + `Playlist.Add` + `Player.Open` 建立视频播放列表，让大按钮能在同一文件夹不同视频之间切换。若 Kodi 不支持此方式，回退原始单视频播放；原先从电视单独打开的视频可能没有可切换项。新 App 对没有列表的情况会提示。
- **更大的遥控面板**：上一部和下一部各高 56dp，暂停等主要按钮高 47dp，音量键 43dp。仍保留音轨、字幕、±10/30秒、进度和暂停。
- **SMB 文件布局**：「☷ 列表 / ▦ 网格」按钮切换三列封面和横向列表（左侧 125×78dp 缩微图，右侧完整度更高的名称以及观看状态）。偏好保存至手机。
- **✓ 标记**：表示 Kodi 给出的 `playcount > 0`，即已观看记录；不是文件同步/收藏标记。
- **私人电影和私人电视剧**：SMB 文件界面**长按视频文件夹**，选「＋ 添加到私人电影」或「＋ 添加到私人电视剧」。选择过的目录持久存储在手机 App 偏好设置；切回电影/电视剧页面可直接浏览该目录的内容。再次长按可移除。数字名称的 MP4 也能显示，不依赖 TMDB 对片名的识别；简介、年份、评分只有 Kodi 本身提供时才显示。
- **Kodi 正式资料库仍然保留**：电影/电视剧页面会组合 Kodi 数据库和以上用户指定的 SMB 私人文件夹；Kodi 正式资料库如需自动搜刮电影元数据，仍需要在 Kodi 中为电影/电视剧设置内容类型并扫描。
- **连接状态改进**：单次播放状态轮询错误不再把已经连通的 Kodi 直接显示为断线。

## 手机怎么操作

1. 电视 Kodi 必须运行且已开启「设置 → 服务 → 控制 → 允许通过 HTTP 远程控制」，确保端口、账号一致。
2. 手机 App 点击「⚙ 连接」填入电视的 Kodi IP 和端口。不要把 SMB 共享盘 IP 当成 Kodi 电视 IP。
3. 打开「SMB 文件」，进入 `airdisk`，选择 **网格或列表**。首次抽帧会比直接显示封面慢，随后会使用本机缓存。
4. 点击视频，在详情框里点击「在 Google TV 上播放」。同文件夹多个视频一起加入 Kodi 临时播放列表，随后用大按钮切换。
5. 在 **SMB 文件** 中长按想归类的**文件夹**，选「加入私人电影」或「加入私人电视剧」，切换到对应标签就能看到视频文件；如果里面有子文件夹，还可以继续进入查看。
6. 对于已观看的视频，✓ 来自 Kodi 自己的播放记录。

## GitHub Actions 编译 Android APK

项目使用 Gradle 8.9、AGP 8.7.3、JDK 17、Android SDK 35。可任选：

- 上传解压后的**所有源码文件**（含隐藏目录 `.github/workflows/build-apk.yml`）到 GitHub 仓库根目录，进入 Actions 手动运行。
- 如果在手机 GitHub 网页上传整个 ZIP，则**还要单独创建** `.github/workflows/build-apk.yml` 并粘贴 ZIP 里的同名文件。工作流会在根目录未发现 `settings.gradle` 时自动解压 ZIP。

在 Actions → `Build Kodi Cinema Remote APK` → `Run workflow`，完成后从 Artifacts 下载 `KodiCinemaRemote-v2.1-debug.zip`，解压得到 `KodiCinemaRemote-v2.1-debug.apk`。

**编译与设备验证说明：** 当前交付物为完整可编译项目源码；本环境没有 Android SDK，尚未实际生成 v2.1 APK，也无法直连你的局域网验证缩微图/播放列表。调试 APK 需经 GitHub Actions 编译；请不要把上传的旧版 v2.0 APK 误认为新版。

注意：Kodi 的 HTTP 基本认证不是端到端加密，仅用于可信家庭局域网，不应暴露到公网。手机端 Kodi 密码仅保留在当前进程内存，不存盘。

## Kodi 参考

- https://kodi.wiki/view/Webserver （`/image/`, `/vfs/`）
- https://kodi.wiki/view/JSON-RPC_API/v12 （Files.GetDirectory、Playlist.Add、Player.Open、Player.GoTo）
