package com.example.kodismbremote;

import android.app.Activity;
import android.app.AlertDialog;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.media.MediaMetadataRetriever;
import java.io.File;
import java.io.FileOutputStream;
import java.security.MessageDigest;
import java.util.HashMap;

import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.Editable;
import android.text.InputType;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.util.Base64;
import android.util.LruCache;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Kodi Cinema v2.1. No external Android dependencies. Phone only issues RPC, never relays video. */
public class MainActivity extends Activity {
    private static final int BG=Color.rgb(8,12,22), SURFACE=Color.rgb(20,29,45), CARD=Color.rgb(27,38,56);
    private static final int TEXT=Color.rgb(245,248,253), MUTED=Color.rgb(157,175,197), TEAL=Color.rgb(60,220,201), BORDER=Color.rgb(47,62,84);
    private final Handler ui=new Handler(Looper.getMainLooper());
    private final ExecutorService network=Executors.newSingleThreadExecutor();
    private final ExecutorService images=Executors.newFixedThreadPool(3);
    private final LruCache<String,Bitmap> bitmapCache=new LruCache<String,Bitmap>(16*1024*1024){
        @Override protected int sizeOf(String key,Bitmap value){return value.getByteCount();}
    };
    private EditText hostField, portField, userField, passField, search;
    private TextView status, pathLabel, nowPlaying, clock, pauseButton, libraryTitle, categoryHint, featuredTitle, featuredSub;
    private ImageView featuredImage;
    private LinearLayout connectionBox, tabs, heroBox, browserBar;
    private GridView grid;
    private TextView viewToggle;
    private final ArrayList<String> privateMovies=new ArrayList<>(), privateTV=new ArrayList<>();
    private boolean listView=false;
    private int loadedModeGeneration=0;
    private SeekBar seek;
    private ProgressBar loading;
    private GalleryAdapter adapter;
    private final ArrayList<MediaItem> records=new ArrayList<>(), shown=new ArrayList<>();
    private final ArrayList<String> history=new ArrayList<>();
    private String host="",port="8080",username="",password="", currentPath="";
    private boolean connected=false,seeking=false,showSettings=true;
    private int playerId=-1, mode=0, filter=0, generation=0;
    private long lastStatus=0;
    private static final String[] MODES={"电影","电视剧","SMB 文件","最近添加"};

    private static class MediaItem {
        String title="", path="",poster="",fanart="",plot="",genre="",tagline="";
        int year=0,playcount=0,runtime=0,movieId=-1,showId=-1,episodeId=-1;
        double rating=0,resume=0,total=0;
        boolean folder=false;
        static MediaItem from(JSONObject j,int type){
            MediaItem m=new MediaItem();
            m.title=j.optString("title", j.optString("label","未命名"));
            if(m.title.isEmpty())m.title=j.optString("label","未命名");
            m.path=j.optString("file", "");
            m.plot=j.optString("plot",""); m.tagline=j.optString("tagline","");
            m.poster=j.optString("thumbnail","");m.fanart=j.optString("fanart","");
            JSONObject art=j.optJSONObject("art");
            if(art!=null){ if(art.has("poster"))m.poster=art.optString("poster",m.poster); if(art.has("fanart"))m.fanart=art.optString("fanart",m.fanart); }
            JSONArray genres=j.optJSONArray("genre"); if(genres!=null && genres.length()>0) m.genre=genres.optString(0,"");
            m.year=j.optInt("year",0);m.rating=j.optDouble("rating",0);
            m.runtime=j.optInt("runtime",0);m.playcount=j.optInt("playcount",0);
            m.movieId=j.optInt("movieid",-1);m.showId=j.optInt("tvshowid",-1);m.episodeId=j.optInt("episodeid",-1);
            JSONObject position=j.optJSONObject("resume"); if(position!=null){m.resume=position.optDouble("position",0);m.total=position.optDouble("total",0);}
            m.folder=type==2 && "directory".equals(j.optString("filetype"));
            if(type==2){m.title=j.optString("label",m.title); if(m.title.isEmpty())m.title=m.path;}
            return m;
        }
    }
    private int dp(float n){return Math.round(n*getResources().getDisplayMetrics().density);}
    private LinearLayout col(){LinearLayout v=new LinearLayout(this);v.setOrientation(LinearLayout.VERTICAL);return v;}
    private LinearLayout row(){LinearLayout v=new LinearLayout(this);v.setOrientation(LinearLayout.HORIZONTAL);v.setGravity(Gravity.CENTER_VERTICAL);return v;}
    private LinearLayout.LayoutParams lp(int w,int h){return new LinearLayout.LayoutParams(w<0?w:dp(w),h<0?h:dp(h));}
    private GradientDrawable bg(int color,int radius){GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(dp(radius));return d;}
    private GradientDrawable bordered(int color,int radius){GradientDrawable d=bg(color,radius);d.setStroke(dp(1),BORDER);return d;}
    private TextView txt(String content,int sp,int color,boolean bold){TextView t=new TextView(this);t.setText(content);t.setTextSize(sp);t.setTextColor(color);if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);t.setGravity(Gravity.CENTER_VERTICAL);return t;}
    private TextView pill(String name,int tint,View.OnClickListener action){TextView t=txt(name,12,tint,true);t.setGravity(Gravity.CENTER);t.setPadding(dp(10),0,dp(10),0);t.setBackground(bordered(CARD,14));t.setOnClickListener(action);return t;}
    private EditText field(String hint,boolean secret){EditText e=new EditText(this);e.setSingleLine(true);e.setTextSize(13);e.setTextColor(TEXT);e.setHintTextColor(MUTED);e.setHint(hint);e.setPadding(dp(10),0,dp(10),0);e.setBackground(bordered(BG,10));if(secret)e.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_PASSWORD);return e;}
    private void spacer(LinearLayout l,int h){l.addView(new View(this),lp(1,h));}
    private void weight(LinearLayout p,View v,int h,float amount){p.addView(v,new LinearLayout.LayoutParams(0,dp(h),amount));}

    @Override public void onCreate(Bundle b){super.onCreate(b);getWindow().setStatusBarColor(BG);getWindow().setNavigationBarColor(BG);buildUi();
        hostField.setText(getPreferences(MODE_PRIVATE).getString("host","192.168.0.79"));
        portField.setText(getPreferences(MODE_PRIVATE).getString("port","8080"));
        userField.setText(getPreferences(MODE_PRIVATE).getString("user","kodi"));
        loadCollections();
        listView=getPreferences(MODE_PRIVATE).getBoolean("smb_list",false);
        ui.postDelayed(poller,2500);
    }
    private void buildUi(){
        LinearLayout root=col(); root.setBackgroundColor(BG);root.setPadding(dp(14),dp(8),dp(14),0);setContentView(root);
        LinearLayout header=row();
        LinearLayout brand=col();TextView title=txt("CINEMA  /  KODI",21,TEXT,true);brand.addView(title,lp(-1,30));
        status=txt("● 未连接 · 先打开 Google TV 上的 Kodi",11,MUTED,false);status.setSingleLine(true);brand.addView(status,lp(-1,20));
        header.addView(brand,new LinearLayout.LayoutParams(0,dp(57),1));
        TextView gear=pill("⚙  连接",TEAL,v->{showSettings=!showSettings;connectionBox.setVisibility(showSettings?View.VISIBLE:View.GONE);});
        header.addView(gear,lp(88,37));root.addView(header,lp(-1,61));

        connectionBox=col();connectionBox.setBackground(bordered(SURFACE,14));connectionBox.setPadding(dp(9),dp(9),dp(9),dp(10));
        LinearLayout addr=row();hostField=field("Google TV IP",false);portField=field("端口",false);portField.setInputType(InputType.TYPE_CLASS_NUMBER);
        weight(addr,hostField,41,3);LinearLayout.LayoutParams p=lp(5,1);addr.addView(new View(this),p);weight(addr,portField,41,1);connectionBox.addView(addr,lp(-1,42));spacer(connectionBox,7);
        LinearLayout auth=row();userField=field("用户名",false);passField=field("Kodi 密码（不保存）",true);weight(auth,userField,41,1);auth.addView(new View(this),lp(5,1));weight(auth,passField,41,1.6f);connectionBox.addView(auth,lp(-1,42));spacer(connectionBox,7);
        TextView connect=pill("连接 Kodi 并加载影音库     →",BG,v->connect());connect.setBackground(bg(TEAL,11));connect.setTextSize(14);connectionBox.addView(connect,lp(-1,43));
        root.addView(connectionBox,lp(-1,-2));

        tabs=row();tabs.setPadding(0,dp(8),0,dp(6));root.addView(tabs,lp(-1,59));renderTabs();
        search=field("搜索影片名称、年份、类型",false);search.setSingleLine(true);root.addView(search,lp(-1,43));
        search.addTextChangedListener(new TextWatcher(){public void beforeTextChanged(CharSequence s,int st,int c,int a){}public void onTextChanged(CharSequence s,int st,int before,int count){filterAndRender();}public void afterTextChanged(Editable e){}});
        spacer(root,9);

        heroBox=col();heroBox.setBackground(bordered(SURFACE,16));
        FrameLayout hero=new FrameLayout(this);featuredImage=new ImageView(this);featuredImage.setScaleType(ImageView.ScaleType.CENTER_CROP);hero.addView(featuredImage,new FrameLayout.LayoutParams(-1,-1));
        GradientDrawable overlay=new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,new int[]{Color.rgb(14,19,31),0xD2111828,0x55202B42});
        View shade=new View(this);shade.setBackground(overlay);hero.addView(shade,new FrameLayout.LayoutParams(-1,-1));
        LinearLayout featured=col();featured.setPadding(dp(14),dp(12),dp(12),dp(12));
        TextView badge=txt("✦  FEATURED COLLECTION",10,TEAL,true);featured.addView(badge,lp(-1,25));
        featuredTitle=txt("你的私人影音库",22,TEXT,true);featuredTitle.setMaxLines(2);featuredTitle.setEllipsize(TextUtils.TruncateAt.END);featured.addView(featuredTitle,lp(-1,57));
        featuredSub=txt("扫描 Kodi 电影资料库后自动呈现封面",12,MUTED,false);featuredSub.setMaxLines(2);featured.addView(featuredSub,lp(-1,40));
        featured.addView(pill("查看内容 / 添加 SMB 影片  ›",TEAL,v->{if(!shown.isEmpty())showDetails(shown.get(0));else{selectMode(2);Toast.makeText(this,"在 SMB 文件中长按视频文件夹，可加入私人电影或电视剧",Toast.LENGTH_LONG).show();}}),lp(192,32));
        hero.addView(featured,new FrameLayout.LayoutParams(-1,-1));heroBox.addView(hero,lp(-1,168));root.addView(heroBox,lp(-1,168));
        spacer(root,9);

        browserBar=row();libraryTitle=txt("精选片库",16,TEXT,true);browserBar.addView(libraryTitle,new LinearLayout.LayoutParams(0,dp(36),1));
        categoryHint=pill("全部 ▾",MUTED,v->chooseFilter());browserBar.addView(categoryHint,lp(82,34));
        browserBar.addView(new View(this),lp(5,1));
        viewToggle=pill("☷ 列表",TEAL,v->toggleLayout());browserBar.addView(viewToggle,lp(75,34));viewToggle.setVisibility(View.GONE);
        root.addView(browserBar,lp(-1,37));
        pathLabel=txt("电影 / 电视剧使用 Kodi 已扫描的资料库",11,MUTED,false);pathLabel.setSingleLine(true);pathLabel.setEllipsize(TextUtils.TruncateAt.MIDDLE);pathLabel.setOnClickListener(v->goBackFolder());root.addView(pathLabel,lp(-1,23));
        grid=new GridView(this);grid.setNumColumns(3);grid.setHorizontalSpacing(dp(10));grid.setVerticalSpacing(dp(12));grid.setStretchMode(GridView.STRETCH_COLUMN_WIDTH);
        grid.setSelector(android.R.color.transparent);grid.setClipToPadding(false);grid.setPadding(0,dp(7),0,dp(12));adapter=new GalleryAdapter();grid.setAdapter(adapter);
        grid.setOnItemClickListener((parent,v,pos,id)->{if(pos<shown.size())onItem(shown.get(pos));});
        grid.setOnItemLongClickListener((parent,v,pos,id)->{if(pos<shown.size()&&shown.get(pos).folder){showFolderActions(shown.get(pos));return true;}return false;});
        root.addView(grid,new LinearLayout.LayoutParams(-1,0,1));

        loading=new ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal);loading.setIndeterminate(true);loading.setVisibility(View.GONE);root.addView(loading,lp(-1,3));
        LinearLayout mini=col();mini.setBackground(bordered(SURFACE,16));mini.setPadding(dp(12),dp(6),dp(12),dp(9));
        LinearLayout head=row();TextView playingLabel=txt("● NOW PLAYING",10,TEAL,true);head.addView(playingLabel,new LinearLayout.LayoutParams(0,dp(20),1));
        TextView audio=pill("音轨",MUTED,v->selectStream(false));TextView subs=pill("字幕",MUTED,v->selectStream(true));head.addView(audio,lp(53,28));head.addView(new View(this),lp(5,1));head.addView(subs,lp(53,28));mini.addView(head,lp(-1,28));
        nowPlaying=txt("电视还没有播放影片",13,TEXT,true);nowPlaying.setSingleLine(true);nowPlaying.setEllipsize(TextUtils.TruncateAt.MIDDLE);mini.addView(nowPlaying,lp(-1,22));
        seek=new SeekBar(this);seek.setMax(1000);seek.setProgressTintList(android.content.res.ColorStateList.valueOf(TEAL));seek.setThumbTintList(android.content.res.ColorStateList.valueOf(TEAL));mini.addView(seek,lp(-1,27));
        seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){public void onProgressChanged(SeekBar bar,int progress,boolean fromUser){if(fromUser)clock.setText(String.format(Locale.ROOT,"跳到 %.1f%%",progress/10.0));}public void onStartTrackingTouch(SeekBar bar){seeking=true;}public void onStopTrackingTouch(SeekBar bar){double x=bar.getProgress()/10.0;seeking=false;controlPlayer("Player.Seek",obj("value",obj("percentage",x)));}});
        LinearLayout transport=row();clock=txt("00:00 / 00:00",12,MUTED,false);
        transport.addView(clock,new LinearLayout.LayoutParams(0,dp(48),1.25f));
        TextView back=pill("−10s",TEXT,v->controlPlayer("Player.Seek",obj("value",obj("seconds",-10))));weight(transport,back,47,1.05f);
        pauseButton=pill("▶",BG,v->controlPlayer("Player.PlayPause",obj("play","toggle")));pauseButton.setBackground(bg(TEAL,12));pauseButton.setTextSize(24);weight(transport,pauseButton,47,1.15f);
        TextView forward=pill("+30s",TEXT,v->controlPlayer("Player.Seek",obj("value",obj("seconds",30))));weight(transport,forward,47,1.05f);
        TextView stop=pill("■",TEXT,v->controlPlayer("Player.Stop",new JSONObject()));weight(transport,stop,47,.72f);
        mini.addView(transport,lp(-1,52));spacer(mini,5);
        LinearLayout skips=row();
        TextView previous=pill("⏮  上一个视频",TEXT,v->skipVideo(false));
        TextView next=pill("下一个视频  ⏭",TEXT,v->skipVideo(true));
        previous.setTextSize(15);next.setTextSize(15);
        weight(skips,previous,56,1);skips.addView(new View(this),lp(8,1));weight(skips,next,56,1);
        mini.addView(skips,lp(-1,56));spacer(mini,5);
        LinearLayout volumes=row();
        TextView less=pill("🔉  音量 −",MUTED,v->kodiVolume("decrement"));
        TextView more=pill("音量 +  🔊",MUTED,v->kodiVolume("increment"));
        weight(volumes,less,43,1);volumes.addView(new View(this),lp(8,1));weight(volumes,more,43,1);
        mini.addView(volumes,lp(-1,43));root.addView(mini,lp(-1,-2));spacer(root,5);
        showEmpty("连接 Kodi 后自动读取电影资料库。",false);
    }
    private void renderTabs(){tabs.removeAllViews();for(int i=0;i<MODES.length;i++){final int index=i;TextView t=pill(MODES[i],i==mode?BG:MUTED,v->selectMode(index));if(i==mode)t.setBackground(bg(TEAL,12));else t.setBackground(bordered(SURFACE,12));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,dp(40),1);if(i>0)p.leftMargin=dp(5);tabs.addView(t,p);}}
    private JSONObject obj(String k,Object v){JSONObject j=new JSONObject();try{j.put(k,v);}catch(Exception ignored){}return j;}
    private JSONArray props(String... names){JSONArray a=new JSONArray();for(String v:names)a.put(v);return a;}
    private interface Work {void run() throws Exception;}
    private void task(Work job){network.execute(()->{try{job.run();}catch(Exception e){fail(e);}});}
    private void fail(Exception e){String m=e.getMessage()==null?e.toString():e.getMessage();ui.post(()->{loading.setVisibility(View.GONE);status.setText("● "+m);Toast.makeText(this,m,Toast.LENGTH_LONG).show();});}
    private JSONObject rpc(String method,JSONObject params)throws Exception{
        if(host.isEmpty())throw new Exception("请先连接 Kodi");
        HttpURLConnection c=(HttpURLConnection)new URL("http://"+host+":"+port+"/jsonrpc").openConnection();
        c.setRequestMethod("POST");c.setDoOutput(true);c.setConnectTimeout(4000);c.setReadTimeout(9000);
        c.setRequestProperty("Content-Type","application/json; charset=utf-8");c.setRequestProperty("Accept","application/json");
        if(!username.isEmpty()||!password.isEmpty())c.setRequestProperty("Authorization","Basic "+Base64.encodeToString((username+":"+password).getBytes(StandardCharsets.UTF_8),Base64.NO_WRAP));
        JSONObject body=obj("jsonrpc","2.0");body.put("method",method);body.put("id",1);if(params!=null)body.put("params",params);
        byte[] bytes=body.toString().getBytes(StandardCharsets.UTF_8);
        try{c.setFixedLengthStreamingMode(bytes.length);try(OutputStream out=c.getOutputStream()){out.write(bytes);}int code=c.getResponseCode();
            if(code==401)throw new Exception("Kodi 账号或密码错误 (401)");if(code!=200)throw new Exception("Kodi HTTP "+code);
            ByteArrayOutputStream out=new ByteArrayOutputStream();try(InputStream in=c.getInputStream()){byte[] b=new byte[8192];int n;while((n=in.read(b))!=-1)out.write(b,0,n);}
            JSONObject answer=new JSONObject(out.toString("UTF-8"));
            if(answer.has("error"))throw new Exception(method+": "+answer.getJSONObject("error").optString("message","调用失败"));return answer;
        }finally{c.disconnect();}
    }
    private void connect(){String h=hostField.getText().toString().trim(),p=portField.getText().toString().trim();
        if(!h.matches("[a-zA-Z0-9.\\-]+")||h.isEmpty()){Toast.makeText(this,"请输入电视的局域网 IP",Toast.LENGTH_LONG).show();return;}
        if(!p.matches("\\d{1,5}")||Integer.parseInt(p)>65535||Integer.parseInt(p)<1){Toast.makeText(this,"端口需为 1–65535",Toast.LENGTH_SHORT).show();return;}
        host=h;port=p;username=userField.getText().toString().trim();password=passField.getText().toString();connected=false;
        getPreferences(MODE_PRIVATE).edit().putString("host",host).putString("port",port).putString("user",username).apply();
        status.setText("● 正在连接 Kodi...");loading.setVisibility(View.VISIBLE);
        task(()->{rpc("JSONRPC.Ping",new JSONObject());connected=true;ui.post(()->{status.setText("● 已连接 · "+host+":"+port);connectionBox.setVisibility(View.GONE);showSettings=false;});loadMode(mode);pollStatus();});
    }
    private void selectMode(int value){mode=value;loadedModeGeneration++;filter=0;categoryHint.setText("全部 ▾");search.setText("");history.clear();currentPath="";renderTabs();
        heroBox.setVisibility(mode==2?View.GONE:View.VISIBLE);
        viewToggle.setVisibility(mode==2?View.VISIBLE:View.GONE);updateLayout();pathLabel.setText(mode==2?"正在读取 Kodi 中配置的视频源":"资料库海报来自 Kodi，点击封面看详情");
        if(connected){loading.setVisibility(View.VISIBLE);task(()->loadMode(mode));}else showEmpty("请先连接 Kodi",false);
    }
    private void loadMode(int requested)throws Exception {if(requested==2){loadSources();return;}
        final int requestGeneration=loadedModeGeneration;
        String api=requested==1?"VideoLibrary.GetTVShows":requested==3?"VideoLibrary.GetRecentlyAddedMovies":"VideoLibrary.GetMovies";
        JSONArray fields=requested==1?props("title","year","rating","plot","genre","thumbnail","fanart","art","playcount"):
            props("title","year","rating","plot","genre","runtime","thumbnail","fanart","art","file","playcount","resume","tagline");
        JSONObject args=obj("properties",fields);args.put("limits",obj("start",0).put("end",500));
        JSONObject answer=rpc(api,args).optJSONObject("result");JSONArray list=answer==null?null:answer.optJSONArray(requested==1?"tvshows":"movies");
        ArrayList<MediaItem> out=new ArrayList<>();if(list!=null)for(int i=0;i<list.length();i++)out.add(MediaItem.from(list.getJSONObject(i),requested));
        if(requested==0||requested==1){
            for(String folder : new ArrayList<>(requested==0?privateMovies:privateTV)){
                try{out.addAll(fetchDirectory(folder));}catch(Exception ex){android.util.Log.w("KodiCinema", "私人文件夹暂时无法读取: "+folder, ex);}
            }
        }
        ui.post(()->{if(mode!=requested||requestGeneration!=loadedModeGeneration)return;libraryTitle.setText(requested==1?"电视剧":requested==3?"最近添加":"你的电影 · "+out.size()+" 个");
            loading.setVisibility(View.GONE);setRecords(out);pathLabel.setText(out.isEmpty()?"暂无内容：到 SMB 文件长按视频文件夹，可加入私人电影或电视剧。":"Kodi 影音库 + 已添加的 SMB 私人文件夹");});
    }
    private void loadSources()throws Exception{
        JSONObject result=rpc("Files.GetSources",obj("media","video")).optJSONObject("result");JSONArray sources=result==null?null:result.optJSONArray("sources");
        ArrayList<MediaItem> out=new ArrayList<>();if(sources!=null)for(int i=0;i<sources.length();i++){
            JSONObject s=sources.getJSONObject(i);MediaItem item=new MediaItem();item.title=s.optString("label","视频源");item.path=s.optString("file","");item.folder=true;out.add(item);}
        ui.post(()->{if(mode!=2)return;history.clear();currentPath="";libraryTitle.setText("SMB 视频源");pathLabel.setText("选择共享硬盘或文件夹 · 点击视频开始浏览");loading.setVisibility(View.GONE);setRecords(out);});
    }
    private ArrayList<MediaItem> fetchDirectory(String path)throws Exception{
        JSONObject args=obj("directory",path);args.put("media","video");
        JSONArray files;
        try{
            args.put("properties",props("title","thumbnail","art","playcount","resume"));
            JSONObject r=rpc("Files.GetDirectory",args).optJSONObject("result");files=r==null?null:r.optJSONArray("files");
        }catch(Exception unsupported){
            // Fallback only when older Kodi rejects a property, preserving normal browsing.
            args.put("properties",props("thumbnail","playcount"));
            try{JSONObject r=rpc("Files.GetDirectory",args).optJSONObject("result");files=r==null?null:r.optJSONArray("files");}
            catch(Exception ignored){args.remove("properties");JSONObject r=rpc("Files.GetDirectory",args).optJSONObject("result");files=r==null?null:r.optJSONArray("files");}
        }
        ArrayList<MediaItem> out=new ArrayList<>();if(files!=null)for(int i=0;i<files.length();i++){
            MediaItem m=MediaItem.from(files.getJSONObject(i),2);if(!m.path.isEmpty())out.add(m);
        }
        Collections.sort(out,Comparator.comparing((MediaItem m)->!m.folder).thenComparing(m->m.title.toLowerCase(Locale.ROOT)));
        return out;
    }
    private void openDir(String path){if(!connected)return;final int selectedMode=mode;int gen=++loadedModeGeneration;
        loading.setVisibility(View.VISIBLE);pathLabel.setText("正在打开文件夹...");
        task(()->{ArrayList<MediaItem> out=fetchDirectory(path);
            ui.post(()->{if(mode!=selectedMode||gen!=loadedModeGeneration)return;
                currentPath=path;libraryTitle.setText("硬盘文件 · "+out.size());
                pathLabel.setText("‹ 点击返回上层 / "+path);loading.setVisibility(View.GONE);setRecords(out);});});
    }
    private void toggleLayout(){listView=!listView;getPreferences(MODE_PRIVATE).edit().putBoolean("smb_list",listView).apply();updateLayout();}
    private void updateLayout(){if(grid==null||viewToggle==null)return;
        grid.setNumColumns(mode==2&&listView?1:3);
        viewToggle.setText(listView?"▦ 网格":"☷ 列表");
        if(adapter!=null)adapter.notifyDataSetChanged();
    }
    private void loadCollections(){
        readCollection("private_movie_paths",privateMovies);readCollection("private_tv_paths",privateTV);
    }
    private void readCollection(String key,ArrayList<String> into){
        into.clear();try{JSONArray a=new JSONArray(getPreferences(MODE_PRIVATE).getString(key,"[]"));
            for(int i=0;i<a.length();i++){String v=a.optString(i,"");if(!v.isEmpty())into.add(v);}
        }catch(Exception ignored){}
    }
    private void saveCollections(){
        getPreferences(MODE_PRIVATE).edit().putString("private_movie_paths",new JSONArray(privateMovies).toString())
            .putString("private_tv_paths",new JSONArray(privateTV).toString()).apply();
    }
    private void showFolderActions(MediaItem folder){
        final boolean movie=privateMovies.contains(folder.path),tv=privateTV.contains(folder.path);
        String[] actions={movie?"✓ 已在私人电影 · 点击移除":"＋ 添加到私人电影",tv?"✓ 已在私人电视剧 · 点击移除":"＋ 添加到私人电视剧","进入文件夹"};
        new AlertDialog.Builder(this).setTitle(folder.title).setItems(actions,(d,which)->{
            if(which==2){history.add(currentPath);openDir(folder.path);return;}
            ArrayList<String> selected=which==0?privateMovies:privateTV;
            if(selected.contains(folder.path))selected.remove(folder.path);else selected.add(folder.path);
            saveCollections();Toast.makeText(this,"私人影音库文件夹设置已保存",Toast.LENGTH_SHORT).show();
        }).setNegativeButton("取消",null).show();
    }
    private void setRecords(ArrayList<MediaItem> list){records.clear();records.addAll(list);filterAndRender();}
    private void showEmpty(String message,boolean needsScan){records.clear();shown.clear();if(adapter!=null)adapter.notifyDataSetChanged();
        if(featuredTitle!=null){featuredTitle.setText(needsScan?"还没有电影海报":"欢迎使用 Kodi Cinema");featuredSub.setText(message);featuredImage.setImageDrawable(null);}}
    private void filterAndRender(){if(shown==null||adapter==null||search==null)return;String q=search.getText().toString().trim().toLowerCase(Locale.ROOT);shown.clear();
        for(MediaItem m:records){if(filter==1 && m.playcount>0)continue;if(filter==2 && m.resume<=0)continue;if(!q.isEmpty()&&!(m.title+" "+m.year+" "+m.genre).toLowerCase(Locale.ROOT).contains(q))continue;shown.add(m);}
        adapter.notifyDataSetChanged();if(mode!=2)updateFeatured();}
    private void updateFeatured(){if(shown.isEmpty()){featuredTitle.setText("私人影院 · 你的收藏");featuredSub.setText(records.isEmpty()?"到 Kodi 中扫描影片后，会自动显示海报、简介和评分":"没有符合筛选条件的影片");featuredImage.setImageDrawable(null);return;}
        MediaItem m=shown.get(0);featuredTitle.setText(m.title);featuredSub.setText((m.year>0?m.year+"  ·  ":"")+(m.genre.isEmpty()?"高清视频":"电影 / "+m.genre)+(m.rating>0?String.format(Locale.ROOT,"  ·  ★%.1f",m.rating):""));
        String art=m.fanart.isEmpty()?m.poster:m.fanart;loadImage(featuredImage,art);}
    private void chooseFilter(){String[] choices={"全部影片","未观看","继续观看"};new AlertDialog.Builder(this).setTitle("筛选影音库")
        .setItems(choices,(d,n)->{filter=n;categoryHint.setText(choices[n]+" ▾");filterAndRender();}).show();}
    private void goBackFolder(){
        if(!connected)return;
        if(history.isEmpty()){
            if(mode==2){loading.setVisibility(View.VISIBLE);task(this::loadSources);}
            else{loading.setVisibility(View.VISIBLE);task(()->loadMode(mode));}
            return;
        }
        String old=history.remove(history.size()-1);
        if(old.isEmpty()){loading.setVisibility(View.VISIBLE);task(()->loadMode(mode));}
        else openDir(old);
    }
    private void kodiVolume(String direction){
        if(!connected){Toast.makeText(this,"请先连接 Kodi",Toast.LENGTH_SHORT).show();return;}
        task(()->rpc("Application.SetVolume",obj("volume",direction)));
    }
    private void onItem(MediaItem m){if(m.folder){history.add(currentPath);openDir(m.path);}else if(m.showId>=0){showEpisodes(m);}else{showDetails(m);}}
    private void showEpisodes(MediaItem show){loading.setVisibility(View.VISIBLE);task(()->{
        JSONObject args=obj("tvshowid",show.showId);args.put("properties",props("title","episode","season","file","plot","thumbnail","playcount","resume","runtime"));
        JSONObject result=rpc("VideoLibrary.GetEpisodes",args).optJSONObject("result");JSONArray list=result==null?null:result.optJSONArray("episodes");
        ArrayList<MediaItem> episodes=new ArrayList<>();if(list!=null)for(int i=0;i<list.length();i++){
            JSONObject j=list.getJSONObject(i);MediaItem m=MediaItem.from(j,0);m.episodeId=j.optInt("episodeid",-1);m.title=String.format(Locale.ROOT,"S%02dE%02d  %s",j.optInt("season",0),j.optInt("episode",0),m.title);episodes.add(m);}
        ui.post(()->{loading.setVisibility(View.GONE);if(episodes.isEmpty()){Toast.makeText(this,"Kodi 没有找到电视剧分集",Toast.LENGTH_LONG).show();return;}
            String[] names=new String[episodes.size()];for(int i=0;i<episodes.size();i++)names[i]=episodes.get(i).title;
            new AlertDialog.Builder(this).setTitle(show.title+" · 选择剧集").setItems(names,(d,pos)->showDetails(episodes.get(pos))).setNegativeButton("关闭",null).show();});
    });}
    private void showDetails(MediaItem m){
        ScrollView scroller=new ScrollView(this);LinearLayout panel=col();panel.setPadding(dp(18),dp(13),dp(18),dp(18));panel.setBackgroundColor(SURFACE);scroller.addView(panel);
        FrameLayout cover=new FrameLayout(this);cover.setBackground(bg(CARD,15));ImageView poster=new ImageView(this);poster.setScaleType(ImageView.ScaleType.CENTER_CROP);cover.addView(poster,new FrameLayout.LayoutParams(-1,-1));
        String art=m.fanart.isEmpty()?m.poster:m.fanart;loadImage(poster,art,m.folder?"":m.path);panel.addView(cover,lp(-1,185));spacer(panel,12);
        TextView headline=txt(m.title,22,TEXT,true);headline.setMaxLines(3);panel.addView(headline,lp(-1,-2));spacer(panel,7);
        String facts=(m.year>0?m.year+"  ·  ":"")+(m.runtime>0?m.runtime/60+" 分钟  ·  ":"")+(m.genre.isEmpty()?"":m.genre+"  ·  ")+(m.rating>0?String.format(Locale.ROOT,"★ %.1f",m.rating):"");
        TextView meta=txt(facts,12,TEAL,true);panel.addView(meta,lp(-1,-2));spacer(panel,10);
        TextView summary=txt(m.plot.isEmpty()?"暂无剧情介绍。可在电视 Kodi 中更新影片信息。":m.plot,13,MUTED,false);summary.setGravity(Gravity.TOP);panel.addView(summary,lp(-1,-2));spacer(panel,18);
        AlertDialog dialog=new AlertDialog.Builder(this).setView(scroller).create();
        TextView play=pill("▶   在 Google TV 上播放",BG,v->{dialog.dismiss();openFile(m);});play.setBackground(bg(TEAL,12));play.setTextSize(15);panel.addView(play,lp(-1,49));
        if(m.resume>30){spacer(panel,8);TextView resume=pill("⏵   继续观看（Kodi 播放记录）",TEXT,v->{dialog.dismiss();resumeFile(m);});panel.addView(resume,lp(-1,43));}
        dialog.setOnShowListener(x->{if(dialog.getWindow()!=null)dialog.getWindow().setBackgroundDrawable(bg(SURFACE,18));});dialog.show();
        if(dialog.getWindow()!=null){dialog.getWindow().setBackgroundDrawable(bg(SURFACE,18));dialog.getWindow().setLayout(getResources().getDisplayMetrics().widthPixels-dp(34),-2);}
    }
    private void resumeFile(MediaItem m){openFile(m,true);}
    private void openFile(MediaItem m){openFile(m,false);}
    private JSONObject playlistItem(MediaItem m)throws Exception{
        if(m.movieId>=0)return obj("movieid",m.movieId);
        if(m.episodeId>=0)return obj("episodeid",m.episodeId);
        return obj("file",m.path);
    }
    private void openFile(MediaItem m,boolean resume){if(!connected)return;loading.setVisibility(View.VISIBLE);status.setText("● 正在向 Google TV 发送影片...");
        // Opening a single file leaves Kodi with no next item. Build an ordered playlist
        // from the current folder before opening, so Previous/Next work reliably.
        ArrayList<MediaItem> playlist=new ArrayList<>();
        for(MediaItem item:shown)if(!item.folder&&(!item.path.isEmpty()||item.movieId>=0||item.episodeId>=0))playlist.add(item);
        boolean hasSelected=false;for(MediaItem item:playlist)if(item==m)hasSelected=true;
        if(!hasSelected)playlist.add(m);
        task(()->{
            try{
                JSONObject item=playlistItem(m);
                if(playlist.size()>1){
                    JSONArray queue=new JSONArray();int selected=0;
                    for(int i=0;i<playlist.size();i++){MediaItem next=playlist.get(i);queue.put(playlistItem(next));if(next==m)selected=i;}
                    rpc("Playlist.Clear",obj("playlistid",1));
                    rpc("Playlist.Add",obj("playlistid",1).put("item",queue));
                    JSONObject openArgs=obj("item",obj("playlistid",1).put("position",selected));
                    if(resume)openArgs.put("options",obj("resume",true));
                    rpc("Player.Open",openArgs);
                }else{
                    JSONObject openArgs=obj("item",item);openArgs.put("options",obj("resume",resume));
                    rpc("Player.Open",openArgs);
                }
            }catch(Exception playlistError){
                // Keep the previously working direct-play path if a Kodi build rejects playlist setup.
                JSONObject openArgs=obj("item",playlistItem(m));openArgs.put("options",obj("resume",resume));
                rpc("Player.Open",openArgs);
                ui.post(()->Toast.makeText(this,"已播放，但 Kodi 未接受播放列表："+playlistError.getMessage(),Toast.LENGTH_LONG).show());
            }
            ui.post(()->{loading.setVisibility(View.GONE);nowPlaying.setText(m.title);status.setText("● 已发送到 Kodi · 电视开始播放");});
            pollStatus();
        });
    }
    private void skipVideo(boolean next){if(!connected){Toast.makeText(this,"请先连接 Kodi",Toast.LENGTH_SHORT).show();return;}
        task(()->{
            int id=getPlayerId();if(id<0)throw new Exception("Kodi 当前没有播放视频");
            JSONObject data=rpc("Player.GetProperties",obj("playerid",id).put("properties",props("playlistid","position"))).optJSONObject("result");
            int listId=data==null?-1:data.optInt("playlistid",-1);
            int position=data==null?0:data.optInt("position",0);
            if(listId>=0){
                JSONObject list=rpc("Playlist.GetItems",obj("playlistid",listId)).optJSONObject("result");
                JSONArray items=list==null?null:list.optJSONArray("items");
                if(items!=null&&items.length()>1){
                    if((next&&position>=items.length()-1)||(!next&&position<=0)){
                        ui.post(()->Toast.makeText(this,next?"已经是列表最后一个视频":"已经是列表第一个视频",Toast.LENGTH_SHORT).show());return;
                    }
                    rpc("Player.GoTo",obj("playerid",id).put("to",next?"next":"previous"));pollStatus();return;
                }
            }
            JSONObject playing=rpc("Player.GetItem",obj("playerid",id).put("properties",props("file"))).optJSONObject("result");
            JSONObject current=playing==null?null:playing.optJSONObject("item");String path=current==null?"":current.optString("file","");
            ui.post(()->{
                int currentIndex=-1;
                for(int i=0;i<shown.size();i++)if(path.equals(shown.get(i).path)){currentIndex=i;break;}
                int index=currentIndex+(next?1:-1);
                while(index>=0&&index<shown.size()&&shown.get(index).folder)index+=next?1:-1;
                if(currentIndex>=0&&index>=0&&index<shown.size()){openFile(shown.get(index));}
                else Toast.makeText(this,"当前没有可切换的上一部/下一部。请从 SMB 文件夹重新点播。",Toast.LENGTH_LONG).show();
            });
        });
    }
    private int getPlayerId()throws Exception{JSONArray r=rpc("Player.GetActivePlayers",new JSONObject()).optJSONArray("result");if(r==null||r.length()==0)return -1;for(int i=0;i<r.length();i++){JSONObject p=r.getJSONObject(i);if("video".equals(p.optString("type")))return p.optInt("playerid",-1);}return r.getJSONObject(0).optInt("playerid",-1);}
    private void controlPlayer(String method,JSONObject p){if(!connected){Toast.makeText(this,"请先连接 Kodi",Toast.LENGTH_SHORT).show();return;}task(()->{int id=getPlayerId();if(id<0)throw new Exception("Kodi 当前没有播放内容");p.put("playerid",id);rpc(method,p);pollStatus();});}
    private void selectStream(boolean subtitle){if(!connected){Toast.makeText(this,"请先连接 Kodi",Toast.LENGTH_SHORT).show();return;}
        task(()->{int id=getPlayerId();if(id<0)throw new Exception("电视没有播放内容");String key=subtitle?"subtitles":"audiostreams";
            JSONObject data=rpc("Player.GetProperties",obj("playerid",id).put("properties",props(key))).optJSONObject("result");
            JSONArray choices=data==null?null:data.optJSONArray(key);if(choices==null||choices.length()==0)throw new Exception(subtitle?"当前影片没有可选字幕":"当前影片没有可选音轨");
            ArrayList<String> labels=new ArrayList<>();ArrayList<Integer> indices=new ArrayList<>();if(subtitle){labels.add("关闭字幕");indices.add(-1);}
            for(int i=0;i<choices.length();i++){JSONObject c=choices.getJSONObject(i);String name=c.optString("name","");labels.add(c.optString("language","und")+(name.isEmpty()?"":"  ·  "+name));indices.add(c.optInt("index",i));}
            ui.post(()->new AlertDialog.Builder(this).setTitle(subtitle?"切换字幕":"切换音轨").setItems(labels.toArray(new String[0]),(d,pos)->{
                JSONObject a=new JSONObject();try{if(subtitle){if(indices.get(pos)<0)a.put("subtitle","off");else{a.put("subtitle",indices.get(pos));a.put("enable",true);}}else a.put("stream",indices.get(pos));}catch(Exception ignored){}
                controlPlayer(subtitle?"Player.SetSubtitle":"Player.SetAudioStream",a);
            }).setNegativeButton("取消",null).show());
        });
    }
    private final Runnable poller=new Runnable(){@Override public void run(){if(connected&&System.currentTimeMillis()-lastStatus>3000)task(()->pollStatus());ui.postDelayed(this,3500);}};
    private void pollStatus(){try{lastStatus=System.currentTimeMillis();int id=getPlayerId();playerId=id;if(id<0){ui.post(()->{nowPlaying.setText("电视还没有播放影片");clock.setText("00:00 / 00:00");pauseButton.setText("▶");if(!seeking)seek.setProgress(0);});return;}
        JSONObject props=rpc("Player.GetProperties",obj("playerid",id).put("properties",props("time","totaltime","percentage","speed"))).optJSONObject("result");
        JSONObject r=rpc("Player.GetItem",obj("playerid",id).put("properties",props("title","file"))).optJSONObject("result");
        JSONObject playing=r==null?null:r.optJSONObject("item");String title=playing==null?"正在播放":playing.optString("label","正在播放");
        if(title.isEmpty()&&playing!=null)title=playing.optString("title","正在播放");
        double pct=props==null?0:props.optDouble("percentage",0);String timing=formatTime(props==null?null:props.optJSONObject("time"))+" / "+formatTime(props==null?null:props.optJSONObject("totaltime"));
        boolean pause=props!=null&&props.optInt("speed",1)==0;String finalTitle=title;
        ui.post(()->{nowPlaying.setText(finalTitle);pauseButton.setText(pause?"▶":"Ⅱ");if(!seeking){seek.setProgress((int)Math.max(0,Math.min(1000,pct*10)));clock.setText(timing);}});
    }catch(Exception ignored){/* transient polling errors do not imply the RPC connection is down */}}
    private String formatTime(JSONObject j){if(j==null)return "00:00";int h=j.optInt("hours"),m=j.optInt("minutes"),s=j.optInt("seconds");return h>0?String.format(Locale.ROOT,"%d:%02d:%02d",h,m,s):String.format(Locale.ROOT,"%02d:%02d",m,s);}

    private String encoded(String path){try{return URLEncoder.encode(path,"UTF-8").replace("+","%20");}catch(Exception e){return "";}}
    private void loadImage(ImageView view,String kodiPath){loadImage(view,kodiPath,"");}
    private void loadImage(ImageView view,String kodiPath,String videoPath){
        view.setImageDrawable(null);
        String imageUrl=kodiPath==null||kodiPath.isEmpty()?"":"http://"+host+":"+port+"/image/"+encoded(kodiPath);
        String videoUrl=videoPath==null||!videoPath.toLowerCase(Locale.ROOT).matches("(?s).*\\.(mp4|mkv|avi|mov|m4v|ts|webm|wmv|mpg|mpeg)$")?"":"http://"+host+":"+port+"/vfs/"+encoded(videoPath);
        String cacheKey=host+":"+port+"|"+(videoUrl.isEmpty()?imageUrl:videoUrl);
        view.setTag(cacheKey);if(!connected||cacheKey.endsWith("|"))return;
        Bitmap cached=bitmapCache.get(cacheKey);
        if(cached!=null){view.setImageBitmap(cached);return;}
        images.execute(()->{
            Bitmap result=loadThumbnailDisk(cacheKey);
            if(result==null&&!imageUrl.isEmpty())result=downloadKodiImage(imageUrl);
            if(result==null&&!videoUrl.isEmpty())result=extractVideoFrame(videoUrl);
            if(result!=null){bitmapCache.put(cacheKey,result);saveThumbnailDisk(cacheKey,result);
                Bitmap target=result;ui.post(()->{if(cacheKey.equals(view.getTag()))view.setImageBitmap(target);});}
        });
    }
    private Bitmap downloadKodiImage(String url){HttpURLConnection c=null;
        try{c=(HttpURLConnection)new URL(url).openConnection();c.setConnectTimeout(3000);c.setReadTimeout(7000);
            if(!username.isEmpty()||!password.isEmpty())c.setRequestProperty("Authorization","Basic "+Base64.encodeToString((username+":"+password).getBytes(StandardCharsets.UTF_8),Base64.NO_WRAP));
            if(c.getResponseCode()!=200)return null;
            BitmapFactory.Options o=new BitmapFactory.Options();o.inSampleSize=2;
            try(InputStream in=c.getInputStream()){return BitmapFactory.decodeStream(in,null,o);}
        }catch(Exception e){return null;}finally{if(c!=null)c.disconnect();}
    }
    private Bitmap extractVideoFrame(String url){
        MediaMetadataRetriever r=new MediaMetadataRetriever();
        try{
            HashMap<String,String> h=new HashMap<>();
            if(!username.isEmpty()||!password.isEmpty())h.put("Authorization","Basic "+Base64.encodeToString((username+":"+password).getBytes(StandardCharsets.UTF_8),Base64.NO_WRAP));
            r.setDataSource(url,h);
            Bitmap bmp=r.getFrameAtTime(15_000_000L,MediaMetadataRetriever.OPTION_CLOSEST_SYNC);
            if(bmp==null)bmp=r.getFrameAtTime(0,MediaMetadataRetriever.OPTION_CLOSEST_SYNC);
            if(bmp!=null&&bmp.getWidth()>640){int w=640,hgt=Math.max(1,bmp.getHeight()*w/bmp.getWidth());Bitmap small=Bitmap.createScaledBitmap(bmp,w,hgt,true);if(small!=bmp)bmp.recycle();return small;}
            return bmp;
        }catch(Exception e){android.util.Log.w("KodiCinema","Kodi VFS 缩微图提取不可用: "+url,e);return null;}
        finally{try{r.release();}catch(Exception ignored){}}
    }
    private File thumbnailFile(String key){
        try{byte[] digest=MessageDigest.getInstance("SHA-256").digest(key.getBytes(StandardCharsets.UTF_8));StringBuilder b=new StringBuilder();for(byte v:digest)b.append(String.format(Locale.US,"%02x",v&255));
            File folder=new File(getCacheDir(),"video-thumbs");if(!folder.exists())folder.mkdirs();return new File(folder,b+".jpg");
        }catch(Exception ignored){return null;}
    }
    private Bitmap loadThumbnailDisk(String key){File f=thumbnailFile(key);if(f==null||!f.isFile())return null;
        BitmapFactory.Options o=new BitmapFactory.Options();o.inSampleSize=1;return BitmapFactory.decodeFile(f.getAbsolutePath(),o);
    }
    private void saveThumbnailDisk(String key,Bitmap bmp){File f=thumbnailFile(key);if(f==null)return;
        try(FileOutputStream out=new FileOutputStream(f)){bmp.compress(Bitmap.CompressFormat.JPEG,82,out);}catch(Exception ignored){}
    }
    private class GalleryAdapter extends BaseAdapter{
        @Override public int getCount(){return shown.size();}@Override public Object getItem(int pos){return shown.get(pos);}@Override public long getItemId(int pos){return pos;}
        @Override public View getView(int pos,View convert,ViewGroup group){
            MediaItem m=shown.get(pos);
            boolean list=mode==2&&listView;
            LinearLayout card=list?row():col();card.setBackground(bordered(SURFACE,12));card.setPadding(dp(4),dp(4),dp(4),dp(list?4:8));
            int screenWidth=getResources().getDisplayMetrics().widthPixels;
            int width=(screenWidth-dp(55))/3;
            int posterHeight=Math.max(dp(108),Math.min(dp(230),(int)(width*1.34f)));
            FrameLayout imageFrame=new FrameLayout(MainActivity.this);imageFrame.setBackground(bg(CARD,9));
            ImageView poster=new ImageView(MainActivity.this);poster.setScaleType(ImageView.ScaleType.CENTER_CROP);
            TextView placeholder=txt(m.folder?"▣":"▶",list?26:35,TEAL,true);placeholder.setGravity(Gravity.CENTER);
            imageFrame.addView(placeholder,new FrameLayout.LayoutParams(-1,-1));
            imageFrame.addView(poster,new FrameLayout.LayoutParams(-1,-1));
            if(!m.poster.isEmpty()||(!m.folder&&!m.path.isEmpty()))loadImage(poster,m.poster,m.folder?"":m.path);
            if(m.resume>0){View progress=new View(MainActivity.this);progress.setBackgroundColor(TEAL);FrameLayout.LayoutParams pp=new FrameLayout.LayoutParams(-1,dp(4),Gravity.BOTTOM);imageFrame.addView(progress,pp);}
            if(m.playcount>0){TextView watched=txt("✓",13,TEAL,true);watched.setGravity(Gravity.CENTER);watched.setBackground(bg(BG,7));FrameLayout.LayoutParams wp=new FrameLayout.LayoutParams(dp(25),dp(23),Gravity.RIGHT|Gravity.TOP);imageFrame.addView(watched,wp);}
            if(list){
                card.addView(imageFrame,lp(125,78));card.addView(new View(MainActivity.this),lp(10,1));
                LinearLayout meta=col();meta.setGravity(Gravity.CENTER_VERTICAL);
                TextView name=txt(m.title,14,TEXT,true);name.setMaxLines(2);name.setEllipsize(TextUtils.TruncateAt.END);meta.addView(name,lp(-1,-2));
                String label=m.folder?"文件夹 · 长按可添加到私人影音库":m.playcount>0?"✓ 已观看 · 点击查看":"未观看 · 点击查看 / 播放";
                TextView info=txt(label,11,m.playcount>0?TEAL:MUTED,false);meta.addView(info,lp(-1,26));
                card.addView(meta,new LinearLayout.LayoutParams(0,dp(78),1));
            }else{
                card.addView(imageFrame,lp(-1,(int)(posterHeight/getResources().getDisplayMetrics().density)));
                TextView name=txt(m.title,12,TEXT,true);name.setSingleLine(true);name.setEllipsize(TextUtils.TruncateAt.END);name.setPadding(dp(5),0,dp(4),0);card.addView(name,lp(-1,25));
                String label=m.folder?"文件夹 · 长按管理":m.playcount>0?"✓ 已观看":m.year>0?m.year+" · 点击查看":"点按查看";
                TextView secondary=txt(label,10,MUTED,false);secondary.setPadding(dp(5),0,dp(4),0);card.addView(secondary,lp(-1,18));
            }
            return card;
        }
    }
    @Override public void onBackPressed(){if(connected&&(mode==2||!currentPath.isEmpty())){goBackFolder();}else super.onBackPressed();}
    @Override protected void onDestroy(){ui.removeCallbacks(poller);network.shutdownNow();images.shutdownNow();super.onDestroy();}
}
