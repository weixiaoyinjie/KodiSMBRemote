# Kodi Cinema Remote v2.0 — Fold6 私人影院

基于原版 KodiSMBRemote v1.0.1 源码升级，保留应用包名 `com.example.kodismbremote` 和原有 Kodi HTTP/JSON-RPC 连接方式。只需要**一款 Fold6 安卓 App** + Google TV 上的 Kodi；无需 Plex / Jellyfin 服务器，也无需手机转发影片数据。

## 功能

- 深色 Plex 风格的海报墙：电影、电视剧、最近添加，以及保留的 SMB 文件夹浏览。
- 点击电影查看封面/背景图、年份、评分、时长、简介，点击按钮在电视 Kodi 播放。
- 电视剧列表与分集选择（Kodi 已入库时）。
- 支持按影片名、年份、类型搜索；全部 / 未观看 / 继续观看筛选。
- 保留播放/暂停、停止、±10/30 秒、进度条、音轨、字幕选择；新增上一项、下一项和 Kodi 音量增减。
- 影片图片由 Kodi 本地 HTTP `/image/` 提供，App 内存缓存缩略图；不需要 TMDB API Key。
- 在“SMB 文件”标签中，仍可浏览**未经 Kodi 扫描**的普通文件夹和视频。

## 重要限制

1. **海报需要 Kodi 先扫描媒体库**：Google TV Kodi → 视频 → 文件 → SMB 文件夹 → 设定内容类型（电影/电视剧）→ 扫描资料库。仅原始文件夹浏览不保证海报/剧情信息。若 Kodi 不返回图像则用简洁占位封面；不会虚构影片图片。
2. Kodi 官方 JSON-RPC 图片接口要求 Kodi 的 HTTP 服务启用且可访问。Kodi 地址示例 `192.168.0.79:8080`，使用前必须以你实际的电视 IP 为准。
3. **播放控制仍由 Kodi 实施**：视频由 Google TV 通过 SMB 直接读取。Kodi 必须正在运行。下一项/上一项只有播放列表存在对应项目时才能切换；Kodi 音量不等同于三星 S61B 的 HDMI 硬件音量。
4. Fold6 与 Google TV 必须处于互通的家庭 LAN，不能开启客户端隔离。HTTP Basic Auth 未加密，只可在可信 LAN 使用；不要将 Kodi HTTP 端口暴露到公网。
5. Kodi 密码仅保存在手机进程内存，IP、端口、用户名存储本地偏好。退出进程后需重新输入密码。
6. 同包名可使用相同签名密钥的正式构建覆盖安装。不同 GitHub Runner 生成的 debug APK 可能签名不同，安装提示冲突时需先卸载旧 App，重新输入连接信息。

## 如何安装

1. Google TV Kodi：设置 → 服务 → 控制 → 允许通过 HTTP 远程控制，端口 8080，设置用户名和密码。添加 SMB 共享并确认能播放。
2. 在 Fold6 安装 APK，填入 Kodi IP / 端口 / 账号 / 密码，点击「连接 Kodi 并加载影音库」。
3. 电影/电视剧海报来自 Kodi 数据库。如果没有封面，请先在电视 Kodi 设置内容类型并扫描。
4. 浏览任意 SMB 文件时进入“SMB 文件”页；点击影片，再按「在 Google TV 上播放」。播放状态实时同步到下方控制栏。
5. 在 SMB 页面，点击路径文字可以返回上层文件夹，或使用手机返回键。

## GitHub Actions 打包

**方式 A（建议）**：解压整个源码 ZIP 后，把文件夹里的所有内容上传到仓库根目录，包括 `.github/workflows/build-apk.yml`。

**方式 B（适合手机浏览器）**：将完整源码 ZIP 上传到仓库根目录；另外在 GitHub 创建文件 `.github/workflows/build-apk.yml`，内容使用随包附带的同名工作流。工作流会自动解压 ZIP，然后用 Gradle 8.9、JDK 17 和 Android SDK 35 编译。

确保仓库不要同时存放多个旧源码 ZIP，避免构建脚本选到旧版。

GitHub → Actions → Build Kodi Cinema Remote APK → Run workflow。成功后下载 `KodiCinemaRemote-v2.0-debug`，解压得到 `KodiCinemaRemote-v2.0-debug.apk`。

**编译状态**：源码静态语法已检查，但当前运行环境没有 Android SDK，因此未进行 Android Gradle 实际编译和真机验证。请在 GitHub Actions 构建后确认。

## Kodi 官方参考

- https://kodi.wiki/view/JSON-RPC_API/Examples
- https://kodi.wiki/view/Artwork/Accessing_with_skins_and_JSON-RPC
- https://kodi.wiki/view/JSON-RPC_API/v13
